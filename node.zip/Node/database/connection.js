const mongoose = require('mongoose');
exports.connectToDb = async () => {
    mongoose.connect('mongodb+srv://asimalidm:asimali0802@training-data.pgqb4dd.mongodb.net/asimdb',{useUnifiedTopology: true, useNewUrlParser: true})
    .then(() => {
        console.log("Connected");
    })
    .catch((err) => {
        console.log(err)
    });
};