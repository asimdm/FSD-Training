const express = require("express");
const router = express.Router();
const userRoutes = require("./user.route");

router.get("/", (req, res) => {
    res.send('This is your page!!');
});

router.use("/user", userRoutes);

module.exports = router;