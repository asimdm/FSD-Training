const userData = require("../database/models/Products")

exports.getUserDetails = async (req, res)=> {
    try{
        const users = await userData.find();
        res.send({
            "statusCode": 200,
            "message": "Data of users",
            "data": users
        });
    }catch(error){
        res.send({
            "statusCode": 400,
            "message": "Data of users",
            "error": error.message
        });
    }
};

exports.setUserDetails = async (req, res) => {
    try{
        const userData = req.body;
        console.log(userData);
        res.send(userData);
    }catch(error){
        res.send(error.message);
    }
};