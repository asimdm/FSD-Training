const mongo =require("./database/connection.js");
// const user = require("./database/models/User");
// const product = require("./database/models/Products");
// const order = require("./database/models/Order");
const express = require('express');
const app = express();
const routes = require("./routes/index.route");

app.use("/", routes);
app.use(express.json());
app.use(express.urlencoded({extended: false}));
  

const main = async () => {
    const connect = await mongo.connectToDb();
    app.listen(8080);
};

main();

// const productObj= new product({
//   "serial_no": "124",
//   "category": "Server",
//   "price": "124",
//   "description": "This is what you came for part 2"
// })

// try{
//   productObj.save();
// }catch(err){
//   console.log(err);
// }